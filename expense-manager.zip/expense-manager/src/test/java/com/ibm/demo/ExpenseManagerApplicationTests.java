package com.ibm.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
