package com.ibm.expensemanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.expensemanager.bean.WalletUser;
import com.ibm.expensemanager.dao.UserRepository;

//#2
@Service
public class UserService {
	
	@Autowired
	UserRepository repo;
	
	public List<WalletUser> getUsers(){
		return (List<WalletUser>) repo.findAll();
	}
	
	public void addWalletUser(WalletUser walletUser) {
		repo.save(walletUser);
	}

	public Optional<WalletUser> getUserByEmailId(String emailId) {
		return repo.findById(emailId);
	}

	

}
