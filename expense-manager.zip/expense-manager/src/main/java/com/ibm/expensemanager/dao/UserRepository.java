package com.ibm.expensemanager.dao;

import java.util.Optional;

import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.expensemanager.bean.WalletUser;

@Repository
public interface UserRepository extends CrudRepository<WalletUser, String> {
	

}