package com.ibm.expensemanager.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.expensemanager.bean.WalletUser;
import com.ibm.expensemanager.service.UserService;

@RestController
//@RequestMapping("/login")
public class UserController {
	
	@Autowired
	UserService service;
	
	@RequestMapping(method = RequestMethod.POST, value = "/loginWithEmail")
	boolean userLogin(@RequestBody WalletUser walletUser){
		boolean flag = false;
		List<WalletUser> user = service.getUsers();
		for(int i = 0; i < user.size(); i++) {
			if(walletUser.getEmail().equals(user.get(i).getEmail()) && walletUser.getPassword().equals(user.get(i).getPassword())) {
				flag = true;
			}
		}
		return flag;
	}
	
	@RequestMapping(method = RequestMethod.POST, value =  "/addUser")
	boolean addUser(@RequestBody WalletUser walletUser) {
		Optional<WalletUser> user = service.getUserByEmailId(walletUser.getEmail());
		if(user.isPresent()) {
			return false;
		}
		else {
			service.addWalletUser(walletUser);
			return true;
		}
	}
	
	@RequestMapping("/all")
	List<WalletUser> getAllUsers(){
		return service.getUsers();
	}
	
}
