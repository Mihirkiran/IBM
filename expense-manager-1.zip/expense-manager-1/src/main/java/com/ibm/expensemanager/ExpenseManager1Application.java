package com.ibm.expensemanager;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.expensemanager.bean.WalletUser;
import com.ibm.expensemanager.dao.UserRepository;

@SpringBootApplication
public class ExpenseManager1Application {

	
	public static void main(String[] args) {
		SpringApplication.run(ExpenseManager1Application.class, args);
	}
	
	
	
	
}
