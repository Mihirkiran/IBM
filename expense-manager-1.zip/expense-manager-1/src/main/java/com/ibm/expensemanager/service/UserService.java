package com.ibm.expensemanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.expensemanager.bean.WalletUser;
import com.ibm.expensemanager.dao.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository repo;
	
	
	public boolean addWalletUser(WalletUser walletUser) {
		Optional<WalletUser> user = getUserByEmailId(walletUser.getEmail());
		if(user.isPresent()) {
			return false;
		}
		else {
			repo.save(walletUser);
			return true;
		}
	}

	public Optional<WalletUser> getUserByEmailId(String emailId) {
		return repo.findById(emailId);
	}
}