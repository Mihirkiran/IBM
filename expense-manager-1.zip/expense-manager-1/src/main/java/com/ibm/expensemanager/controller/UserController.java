package com.ibm.expensemanager.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.expensemanager.bean.WalletUser;
import com.ibm.expensemanager.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	WalletUser walletUser;
	
	@Autowired
	UserService service;
	
	@RequestMapping("user")
	public Principal user(Principal principal) {
		walletUser.setEmail(principal.getName());
		boolean flag = service.addWalletUser(walletUser);
		System.out.println(principal);
		return principal;
	}
}
