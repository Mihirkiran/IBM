package com.ibm.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@RequestMapping("/")
	String getMessage() {
		return "Hello everyone...";
	}
	
	@RequestMapping("/developer")
	String getMesageForUsers() {
		return "Hello developer";
	}
	
	@RequestMapping("/admin")
	String getMessageForAdmin() {
		return "Hello Admin...";
	}
	
	@RequestMapping("/manager")
	String getMessageForManager() {
		return "Hello Manager...";
	}
	
	@RequestMapping("/hr")
	String getMessageForHr() {
		return "Hello Human Resources...";
	}
	
}
