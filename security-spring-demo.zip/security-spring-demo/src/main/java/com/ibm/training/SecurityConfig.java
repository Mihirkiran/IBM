package com.ibm.training;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

//	Overirde for Custom Authentication
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		Setting the configuration on the authentication object
		
		auth.inMemoryAuthentication()
		.withUser("ibm")
		.password("ibm")
		.roles("USER") // ROLE_USER
		.and()
		.withUser("ibmAdmin")
		.password("admin")
		.roles("ADMIN"); // ROLE_ADMIN
			
	}
	
	
//	For Authorization:
	
	@Override
		protected void configure(HttpSecurity http) throws Exception {
			http.authorizeRequests()
			.antMatchers("/admin").hasRole("ADMIN")
			.antMatchers("/users").hasAnyRole("USER", "ADMIN")
			.antMatchers("/").permitAll()
			.and().formLogin();
		}
	
	
	
	
	
//	Get a PasswordEncoder
	@Bean
	PasswordEncoder getPasswordEncoder(){
		return NoOpPasswordEncoder.getInstance();
	}
	
}
