package com.ibm.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SecuritySpringDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuritySpringDemoApplication.class, args);
	}
	
	@RequestMapping("/users")
	String getUserData() {
		return "Hello User, Welcome to our Application...";
	}
	
	
	@RequestMapping("/admin")
	String getAdminData() {
		return "Hey Admin...";
	}
	
	
	@RequestMapping("/")
	String getPublicData() {
		return "This are is open to everyone, requires no authentication...";
	}

}
